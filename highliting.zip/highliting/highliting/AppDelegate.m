//
//  AppDelegate.m
//  highliting
//
//  Created by Alaa Bzour on 8/31/20.
//  Copyright © 2020 Alaa Bzour. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    // Insert code here to initialize your application
}


- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
}


@end
