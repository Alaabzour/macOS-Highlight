//
//  windowCntr.m
//  highliting
//
//  Created by Alaa Bzour on 8/31/20.
//  Copyright © 2020 Alaa Bzour. All rights reserved.
//

#import "windowCntr.h"
#import "OSXAppHidhtlightDeledate.h"

@interface windowCntr () {
   
}

@end

@implementation windowCntr

- (void)windowDidLoad {
    [super windowDidLoad];

    OSXAppHidhtlightDeledate *test = [[OSXAppHidhtlightDeledate alloc]initWithWindowId:5544];
    [test show];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 25 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
        [test end];
        
    });
    
  
}

@end
