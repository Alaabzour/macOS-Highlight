//
//  windowCntr.h
//  highliting
//
//  Created by Alaa Bzour on 8/31/20.
//  Copyright © 2020 Alaa Bzour. All rights reserved.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@interface windowCntr : NSWindowController

@end

NS_ASSUME_NONNULL_END
