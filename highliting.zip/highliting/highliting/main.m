//
//  main.m
//  highliting
//
//  Created by Alaa Bzour on 8/31/20.
//  Copyright © 2020 Alaa Bzour. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // Setup code that might create autoreleased objects goes here.
    }
    return NSApplicationMain(argc, argv);
}
